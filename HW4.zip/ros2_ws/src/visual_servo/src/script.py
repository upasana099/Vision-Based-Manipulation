#!/usr/bin/env python3
# Import the necessary libraries
import rclpy # Python library for ROS 2
from rclpy.node import Node # Handles the creation of nodes
from sensor_msgs.msg import Image # Image is the message type
from cv_bridge import CvBridge # Package to convert between ROS and OpenCV Images
import cv2 # OpenCV library
import numpy as np
from numpy.lib.function_base import average
import matplotlib.pyplot as plt
from tf2_ros import TransformException # Base class to handle exceptions
from tf2_ros.buffer import Buffer # Stores known frames and offers frame graph requests
from tf2_ros.transform_listener import TransformListener # Easy way to request and receive coordinate frame transform information
from std_msgs.msg import Float64MultiArray # Handle float64 arrays
#from tf_transformations import quaternion_matrix
from pyquaternion import Quaternion
#from tf2.transformations import quaternion_matrix
#from tf2_geometry_msgs import  quaternion_matrix


class ImageSubscriber(Node):
  """
  Create an ImageSubscriber class, which is a subclass of the Node class.
  """
  def __init__(self):
    """
    Class constructor to set up the node
    """
    # Initiate the Node class's constructor and give it a name
    super().__init__('image_subscriber')
      
    # Create the subscriber. This subscriber will receive an Image
    # from the video_frames topic. The queue size is 10 messages.

    self.subscription = self.create_subscription(
                                            Image, 
                                            '/camera1/image_raw', 
                                            self.listener_callback, 
                                            10)
    self.subscription # prevent unused variable warning

    # Create the publisher. This publisher will publish an Float64MUltiArray
    # to the video_frames topic. The queue size is 10 messages.
    self.velocity_publisher_ = self.create_publisher(
                                            Float64MultiArray, 
                                            '/forward_velocity_controller/commands',
                                            10)
    self.previous_error_norm = None
    self.current_error_norm = None
    self.color_order = ['blue', 'green', 'purple', 'red']
    self.flag_below_threshold = False

      
    # Used to convert between ROS and OpenCV images
    self.br = CvBridge()
    self.tf_buffer = Buffer()
    self.tf_listener = TransformListener(self.tf_buffer, self)
    #green,blue,purple,red
    self.f_r = np.array([427,371,511,371,510,288,427,287]) # [511,371,427,287,510,288,427,371])
    self.gcx, self.rcx, self.bcx, self.mcx,self.gcy, self.rcy, self.bcy, self.mcy = ([] for i in range(8))
  
  def listener_callback(self, data):
    """
    Callback function.
    """
    # Display the message on the console
    self.get_logger().info('Receiving video frame')
 
    # Convert ROS Image message to OpenCV image
    current_frame = self.br.imgmsg_to_cv2(data,'bgr8')
    self.colorThreshold(current_frame)

    # PLACE YOUR CODE HERE. PROCESS THE CURRENT FRAME AND PUBLISH IT. IF YOU ARE HAVING DIFFICULTY PUBLISHING IT YOU CAN USE THE FOLLOWING LINES TO DISPLAY IT VIA OPENCV FUNCTIONS
  def findCenters(self,img, disp):
    # Finding contour centers : 
    cnts, heirarchy = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    centers =[]
    for c in cnts:
        if cv2.contourArea(c) <= 25:
            continue
        cx = int(average([x for x in c[:,0,0]]))
        cy = int(average([y for y in c[:,0,1]]))
        center = (cx, cy)
        centers.append(center)
    return centers

  def checkConvergence(self,err):
    x_sum, y_sum = 0, 0
    x_sum = sum([abs(i) for i in err[::2]])
    y_sum = sum([abs(i) for i in err[1::2]]) 
    if x_sum < 10 and y_sum < 10:
      return True
    else:
      return False
  
  def plot(self,convergence,val):
    if convergence:   
      plt.plot(self.gcx, self.gcy, color='g', label='Green Center')
      plt.plot(self.rcx, self.rcy, color='r', label='Red Center')
      plt.plot(self.bcx, self.bcy, color='b', label='Blue Center')
      plt.plot(self.mcx, self.mcy, color='m', label='purple Center')
      plt.xlabel('x_coordinate')
      plt.ylabel('y_coordinate')
      plt.legend()
      plt.title("Trajectory of centers over time")
      plt.show()
      plt.savefig('plot.png')
      rclpy.shutdown()
    self.velocity_publisher_.publish(val)

  def masks(self,mask, img):
      imask = mask>0
      color = np.zeros_like(img, np.uint8)
      color[imask] = img[imask]
      return self.findCenters(mask, color)

  def colorThreshold(self,img):      
   

    # Convert to HSV
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # Mask for each color
    masks = {
    "green": cv2.inRange(hsv, (36, 25, 25), (70, 255,255)),
    "blue": cv2.inRange(hsv, (95, 25, 25), (135, 255,255)),
    "red": cv2.inRange(hsv, (0, 100, 25), (15, 255,255)),
    "purple": cv2.inRange(hsv, (140,100,20) , (170,255,255))
      }



    centers = {}
    for color in self.color_order:
        cnts, _ = cv2.findContours(masks[color], cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if cnts:  # Check if any contour is detected
            M = cv2.moments(cnts[0])  # taking the first contour
            if M["m00"] != 0:  # Avoid division by zero
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
                centers[color] = (cX, cY)
            else:
                centers[color] = (0, 0)

 


    # Update your tracking lists
    for color in self.color_order:
      if color == "blue":
          self.bcx.append(centers[color][0])
          self.bcy.append(centers[color][1])
      elif color == "green":
          self.gcx.append(centers[color][0])
          self.gcy.append(centers[color][1])
      elif color == "red":
          self.rcx.append(centers[color][0])
          self.rcy.append(centers[color][1])
      elif color == "purple":
          self.mcx.append(centers[color][0])
          self.mcy.append(centers[color][1])


    # centers
    self.bcx.append(centers["blue"][0])
    self.bcy.append(centers["blue"][1])
    self.gcx.append(centers["green"][0])
    self.gcy.append(centers["green"][1])
    self.mcx.append(centers["purple"][0])
    self.mcy.append(centers["purple"][1])
    self.rcx.append(centers["red"][0])
    self.rcy.append(centers["red"][1])
    
  
    
    f_c = []
    for color in self.color_order:
        f_c.extend(centers[color])
    f_c = np.array(f_c)

    # Compute the error
    # Compute the error
    error = f_c - self.f_r 
    self.previous_error_norm = self.current_error_norm
    self.current_error_norm = np.linalg.norm(error)  # L2 norm of error
    self.get_logger().info(f'Current Error Norm: {self.current_error_norm}')


    # Check if the error converged and if self.current_error_norm is close to 316
    # if self.checkConvergence(error) and abs(self.current_error_norm - 310) < 1e-2:  
    #     self.plot(True, None)  # Assuming you want the convergence parameter to be True in this case
    #     rclpy.shutdown()
    #     return
    # if abs(self.current_error_norm - 310) < 2:
    #         self.plot(True, None)
    #         rclpy.shutdown()
    #         return
    # After computing the error:
    if self.current_error_norm < 100:
        self.flag_below_threshold = True
        val = Float64MultiArray()
        val.data = [0.0, 0.0]
        self.velocity_publisher_.publish(val)
        self.get_logger().info('Error below threshold. Stopping further processing.')
        self.plot(True,val)
        return

        # Check if the error started to increase
    # if self.previous_error_norm is not None and self.current_error_norm > self.previous_error_norm:

    #         self.get_logger().info('Minimum error reached. Stopping calculations.')
    #         rclpy.shutdown()
    #         return


    # Call the function to compute the Jacobian
    try:
      val=self.findJ(error)
      self.velocity_publisher_.publish(val)
    except:
       pass

    


    # f_c = np.array([green_centers,blue_centers,red_centers,purple_centers])
    # f_c = f_c.flatten()# 8 x 1
    # error = [0,0,0,0,0,0,0,0]
    # error = f_c - self.f_r 
    print("error", self.current_error_norm)
    # print("error",error)
    # # self.findJ(error)

  
  # def quaternion_matrix(self, quat):
  #       """Convert a quaternion into a full three-by-three rotation matrix."""
  #       q = Quaternion(quat[3], quat[0], quat[1], quat[2])  # w first
  #       return q.rotation_matrix

  def quaternion_matrix(self, quat):
    x, y, z,w = quat
    rotation_matrix = np.zeros((4, 4))
    
    rotation_matrix[0, 0] = 1 - 2*y*y - 2*z*z
    rotation_matrix[0, 1] = 2*x*y - 2*w*z
    rotation_matrix[0, 2] = 2*x*z + 2*w*y
    
    rotation_matrix[1, 0] = 2*x*y + 2*w*z
    rotation_matrix[1, 1] = 1 - 2*x*x - 2*z*z
    rotation_matrix[1, 2] = 2*y*z - 2*w*x
    
    rotation_matrix[2, 0] = 2*x*z - 2*w*y
    rotation_matrix[2, 1] = 2*y*z + 2*w*x
    rotation_matrix[2, 2] = 1 - 2*x*x - 2*y*y
    
    rotation_matrix[3, 3] = 1.0
    
    return rotation_matrix
  

  def findJ(self,error,lmbda = -0.001):
    L_e_i = -1*np.eye(2)    
    L_e = np.vstack((L_e_i,L_e_i,L_e_i,L_e_i))    
    L_e_inv = np.linalg.pinv(L_e)    
    v_c = -lmbda*L_e_inv @ error
    print(v_c.shape)
    vc=[]
    
    vc.append(v_c[0])
    vc.append(v_c[1])
    vc.append(0)
    vc.append(1)
    vc=np.array(vc,dtype=float)
    v_c=vc
    
    try:
        now = rclpy.time.Time()
        trans = self.tf_buffer.lookup_transform("link1","camera_link",now)
    except TransformException as ex:
        self.get_logger().info(
        f'Could not transform {"link1"} to {"camera_link"}: {ex}')
        return
    Rotation_matrix = self.quaternion_matrix([ trans.transform.rotation.x,
                                        trans.transform.rotation.y,
                                        trans.transform.rotation.z,
                                        trans.transform.rotation.w])
    v_w = Rotation_matrix @ v_c # 4 x 1 # link1 frame velocities
    trans_link1_camera = [trans.transform.translation.x,
                        trans.transform.translation.y,
                        trans.transform.translation.z]

    try:
        now = rclpy.time.Time()
        trans = self.tf_buffer.lookup_transform("link2","camera_link",now)
    except TransformException as ex:
        self.get_logger().info(
        f'Could not transform {"link2"} to {"camera_link"}: {ex}')
        return
    trans_link2_camera = [trans.transform.translation.x,
                        trans.transform.translation.y,
                        trans.transform.translation.z]

    J11 = np.cross(np.array([0,0,1]),trans_link1_camera)
    
    J12 = np.cross(np.array([0,0,1]),trans_link2_camera)
    J21 = np.array([0,0,1])
    J22 = J21
    J = np.hstack((np.vstack((J11,J12)),np.vstack((J21,J22)))) # 6 X 2 
    J_inv = np.linalg.pinv(J) # 2 X 6 
    j_v = J_inv[0:2,0:2] @ v_w[0:2] # 2 X 1
    print(j_v)
    # publish
    val = Float64MultiArray()
    val.data = np.array([j_v[0],j_v[1]]).astype(np.float64).tolist()
    return val
    
   
    
    
  
def main(args=None):
  
  # Initialize the rclpy library
  rclpy.init(args=args)  
  # Create the node
  image_subscriber = ImageSubscriber()  
  # Spin the node so the callback function is called.
  rclpy.spin(image_subscriber)  
   # Spin the node so the callback function is called.
    # As you want to keep checking for a certain number of iterations or until the flag is set, 
    # you can replace rclpy.spin with a loop:
  for _ in range(10000):
        rclpy.spin_once(image_subscriber)
        if image_subscriber.flag_below_threshold:
            break
    
    # Now, check the flag to decide the action:
  if image_subscriber.flag_below_threshold:
        plt.show()
  else:
        print("Error never went below threshold.")
  # Destroy the node explicitly
  # (optional - otherwise it will be done automatically
  # when the garbage collector destroys the node object)
  image_subscriber.destroy_node()  
  # Shutdown the ROS client library for Python
  rclpy.shutdown()
  
if __name__ == '__main__':
  main()