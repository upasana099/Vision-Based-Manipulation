#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64_multi_array.hpp"

using namespace std::chrono_literals;

/* This example creates a subclass of Node and uses std::bind() to register a
* member function as a callback from the timer. */

class MinimalPublisher : public rclcpp::Node
{
public:
    MinimalPublisher(int argc, char *argv[])
    : Node("minimal_publisher"), count_(0)
    {
        publisher_ = this->create_publisher<std_msgs::msg::Float64MultiArray>("/forward_position_controller/commands", 10);
        timer_ = this->create_wall_timer(1000ms, std::bind(&MinimalPublisher::timer_callback, this));

        // Fetch the command line arguments (joint values)
        std::vector<std::string> args = this->get_node_options().arguments();
        if (argc > 2) {
          joint1_position_ = std::stod(argv[1]);
          joint2_position_ = std::stod(argv[2]);
      } else {
          RCLCPP_ERROR(this->get_logger(), "Please provide joint positions as arguments!");
          rclcpp::shutdown();
      }

    }

private:
    void timer_callback()
    {
        auto message = std_msgs::msg::Float64MultiArray();
        message.data.push_back(joint1_position_);
        message.data.push_back(joint2_position_);
        publisher_->publish(message);
    }

    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<std_msgs::msg::Float64MultiArray>::SharedPtr publisher_;
    size_t count_;
    double joint1_position_;
    double joint2_position_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<MinimalPublisher>(argc, argv));
    rclcpp::shutdown();
    return 0;
}






// class MinimalPublisher : public rclcpp::Node
// {
//   public:
//     MinimalPublisher()
// : Node("minimal_publisher"), count_(0)
// {
//   publisher_ = this->create_publisher<std_msgs::msg::Float64MultiArray>("/forward_position_controller/commands", 10);
//   timer_ = this->create_wall_timer(
//   1000ms, std::bind(&MinimalPublisher::timer_callback, this));

//   // Fetch the command line arguments (joint values)
//   std::vector<std::string> args = this->get_node_options().arguments();
//   if (args.size() > 1) {
//     joint1_position_ = std::stod(args[1]);
//     joint2_position_ = std::stod(args[2]);
//   } else {
//     RCLCPP_ERROR(this->get_logger(), "Please provide joint positions as arguments!");
//     rclcpp::shutdown();
//   }
// }
//   private:
//   ...
//   double joint1_position_;
//   double joint2_position_;

//     // MinimalPublisher()
//     // : Node("minimal_publisher"), count_(0)
//     // {
//     //   publisher_ = this->create_publisher<std_msgs::msg::Float64MultiArray>("/forward_position_controller/commands", 10);
//     //   timer_ = this->create_wall_timer(
//     //   1000ms, std::bind(&MinimalPublisher::timer_callback, this));
//     // }

//   private:
//     void timer_callback()
//     {
//       auto message = std_msgs::msg::Float64MultiArray();
//       message.data.push_back(joint1_position_);
//       message.data.push_back(joint2_position_);
//       publisher_->publish(message);
//     //   RCLCPP_INFO(this->get_logger(), "Publishing: '%s'", message.data.c_str());
//       publisher_->publish(message);
//     }
//     rclcpp::TimerBase::SharedPtr timer_;
//     rclcpp::Publisher<std_msgs::msg::Float64MultiArray>::SharedPtr publisher_;
//     size_t count_;
// };

// int main(int argc, char * argv[])
// {
//   rclcpp::init(argc, argv);
//   rclcpp::spin(std::make_shared<MinimalPublisher>());
//   rclcpp::shutdown();
//   return 0;
// }
