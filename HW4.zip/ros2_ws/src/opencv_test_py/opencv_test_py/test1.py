# Basic ROS 2 program to subscribe to real-time streaming 
# video from your built-in webcam
# This code is modified by Berk Calli from the following author.
# Author:
# - Addison Sears-Collins
# - https://automaticaddison.com
  
# Import the necessary libraries
import rclpy # Python library for ROS 2
from rclpy.node import Node # Handles the creation of nodes
from sensor_msgs.msg import Image # Image is the message type
from cv_bridge import CvBridge # Package to convert between ROS and OpenCV Images
import cv2 # OpenCV library
import numpy as np

class ImageSubscriber(Node):
    """
    Create an ImageSubscriber class, which is a subclass of the Node class.
    """
    def __init__(self):
        """
        Class constructor to set up the node
        """
        super().__init__('image_subscriber')
        self.subscription = self.create_subscription(
            Image, 
            '/camera1/image_raw', 
            self.listener_callback, 
            10)
        self.subscription  # prevent unused variable warning

        self.publisher_ = self.create_publisher(Image, 'output_image', 10)
        self.br = CvBridge()
        self.color_order = ['blue', 'green', 'purple', 'red']

    def listener_callback(self, data):
        # Display the message on the console
        self.get_logger().info('Receiving video frame')

        # Convert ROS Image message to OpenCV image
        current_frame = self.br.imgmsg_to_cv2(data)
        hsv = cv2.cvtColor(current_frame, cv2.COLOR_BGR2HSV)

        # Define the HSV range for each color and mask the image
        colors = {
            'blue': ([100, 50, 50], [140, 255, 255]),
            'green': ([40, 50, 50], [80, 255, 255]),
            'red': ([0, 50, 50], [10, 255, 255]),
            'purple': ([130, 50, 50], [170, 255, 255])
        }

        output_image = np.zeros_like(current_frame)

        # Process each color in the standardized order
        for color in self.color_order:
            lower, upper = colors[color]
            mask = cv2.inRange(hsv, tuple(lower), tuple(upper))
            masked = cv2.bitwise_and(current_frame, current_frame, mask=mask)
            output_image = cv2.add(output_image, masked)

            M = cv2.moments(mask)
            if M["m00"] != 0:  # avoid division by zero
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
                cv2.circle(output_image, (cX, cY), 10, (0, 255, 255), 3)
                cv2.circle(output_image, (cX, cY), 1, (0, 255, 255), -1)
                print(f"Center of {color} circle: ({cX}, {cY})")

        cv2.waitKey(1)  # Add a slight pause to refresh the windows
        self.publisher_.publish(self.br.cv2_to_imgmsg(output_image, encoding="bgr8"))

def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()
    rclpy.spin(image_subscriber)
    image_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

